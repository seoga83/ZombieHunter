﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

//클래스에 System.Serializable 이라는 어트리뷰트(Atrribute)를 명시해야
//Inspector 뷰에 노출됨
[System.Serializable]
public class Anim
{
    public AnimationClip idle;
    public AnimationClip runForward;
    public AnimationClip runBackward;
    public AnimationClip runRight;
    public AnimationClip runLeft;
}

public class PlayerCtrl : MonoBehaviour
{
    public GameObject GameOverPanel;
    public Button GoLobbyBtn;

    private float h = 0.0f;
    private float v = 0.0f;

    //접근해야 하는 컴포넌트는 반드시 변수에 할당한 후 사용
    private Transform tr;

    //이동 속도 변수
    public float moveSpeed = 10.0f;

    //회전 속도 변수
    public float rotSpeed = 80.0f;

    //인스펙터뷰에 표시할 애니메이션 클래스 변수
    public Anim anim;

    //아래에 있는 3D 모델의 Animation 컴포넌트에 접근하기 위한 변수
    public Animation _animaion;

    public int hp = 100;
    public int initHp;
    public Image imgHpBar;

    private GameMgr gameMgr;

    string UpdateUrl;

    public GameObject BloodScrPrefab;

    // Start is called before the first frame update
    void Start()
    {
        initHp = hp;

        //스크립스 처음에 Transform 컴포넌트 할당
        tr = GetComponent<Transform>();
        gameMgr = GameObject.FindObjectOfType<GameMgr>();

        //자신의 하위에 있는 Animation 컴포넌트를 찾아와 변수에 할당
        _animaion = GetComponentInChildren<Animation>();

        //Animation 컴포넌트의 애니메이션 클립을 지정하고 실행
        _animaion.clip = anim.idle;
        _animaion.Play();

        if (GoLobbyBtn != null)
            GoLobbyBtn.onClick.AddListener(() =>
            {
                if (GlobalValue.g_BestScore < UIMgr.totScore)
                {
                    GlobalValue.g_BestScore = UIMgr.totScore;
                }

                StartCoroutine(UpdateDataCo());
                //SceneManager.LoadScene("Lobby");
            });

        UpdateUrl = "http://beatleg.dothome.co.kr/Zombie_Updatedata.php";
    }

    IEnumerator UpdateDataCo()
    {
        if (GlobalValue.g_Unique_ID == "")
        {
            SceneManager.LoadScene("Lobby");
            yield break;            //로그인 실패 상태라면 그냥 리턴
        }

        WWWForm form = new WWWForm();
        form.AddField("Input_user", GlobalValue.g_Unique_ID, System.Text.Encoding.UTF8);
        form.AddField("Input_score", GlobalValue.g_BestScore);
        WWW webRequest = new WWW(UpdateUrl, form);
        yield return webRequest;

        System.Text.Encoding enc = System.Text.Encoding.UTF8; //<--이렇게 해야 안드로이드에서 한글이 않깨진다.
        string a_ReStr = enc.GetString(webRequest.bytes);

        if (a_ReStr.Contains("UpDateSuccess~") == true)
        {
            Debug.Log("UpDateScoreSuccess");
        }

        //yield return null;
        SceneManager.LoadScene("Lobby");
    }

    // Update is called once per frame
    void Update()
    {
        if (GameMgr.instance.isGameOver)
            return;

        h = Input.GetAxis("Horizontal");
        v = Input.GetAxis("Vertical");

        //Debug.Log("H = " + h.ToString());
        //Debug.Log("V = " + v.ToString());

        Vector3 moveDir = (Vector3.forward * v) + (Vector3.right * h);

        tr.Translate(moveDir.normalized * moveSpeed * Time.deltaTime, Space.Self);


        if (Input.GetMouseButton(0) == true || Input.GetMouseButton(1) == true)
        {
            tr.Rotate(Vector3.up * rotSpeed * Time.deltaTime * Input.GetAxis("Mouse X") * 3.0f);
        }


        //키보드 입력값을 기준으로 동작할 애니메이션 수행
        if (v >= 0.1f)
        {
            //전진 애니메이션 
            _animaion.CrossFade(anim.runForward.name, 0.3f);
        }
        else if (v <= -0.1f)
        {
            //후진 애니메이션 
            _animaion.CrossFade(anim.runBackward.name, 0.3f);
        }
        else if (h >= 0.1f)
        {
            //오른쪽 이동 애니메이션 
            _animaion.CrossFade(anim.runRight.name, 0.3f);
        }
        else if (h <= -0.1f)
        {
            //왼쪽 이동 애니메이션 
            _animaion.CrossFade(anim.runLeft.name, 0.3f);
        }
        else
        {
            //정지시 idle 애니메이션 
            _animaion.CrossFade(anim.idle.name, 0.3f);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "PUNCH")
        {
            if(!GameMgr.instance.isGameOver)
                Instantiate(BloodScrPrefab);

            hp -= 4;

            imgHpBar.fillAmount = (float)hp / (float)initHp;

            Debug.Log("Player HP = " + hp.ToString());

            if(hp <= 0)
            {
                PlayerDie();
            }
        }
    }

    void PlayerDie()
    {
        //Time.timeScale = 0.0f;

        GameOverPanel.SetActive(true);

        Debug.Log("Player Die !!");

        GameObject[] monsters = GameObject.FindGameObjectsWithTag("MONSTER");

        foreach(GameObject monster in monsters)
        {
            monster.SendMessage("OnPlayerDie", SendMessageOptions.DontRequireReceiver);
        }

        GameMgr.instance.isGameOver = true;
    }
}
