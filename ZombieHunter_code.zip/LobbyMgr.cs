﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using SimpleJSON;

public class UserInfo
{
    public string m_ID = "";
    public string m_Nick = "";
    public int m_BestScore = 0;

    public UserInfo()
    {
    }
};

public class LobbyMgr : MonoBehaviour
{
    public Image FadePanel;
    Color FadeColor;
    bool isFadeIn = true;
    bool isFadeOut = false;
    float FadeTime = 1.0f;
    float TimeTic;

    bool isStartBtn = false;

    public Button PlayBtn;
    public Button RankBtn;
    public Button LogoutBtn;

    public GameObject RankPanel;
    bool isShowing = true;

    List<UserInfo> m_RkList = new List<UserInfo>();
    string GetScoreListUrl;
    float m_RestoreTick = 0.0f;
    int m_My_Rank = 0;
    public Text RankTxt;

    // Start is called before the first frame update
    void Start()
    {
        Cursor.lockState = CursorLockMode.None;

        Time.timeScale = 1.0f;
        TimeTic = FadeTime;

        if (RankBtn != null)
            RankBtn.onClick.AddListener(()=>
            {
                isShowing = !isShowing;
            });

        if (PlayBtn != null)
            PlayBtn.onClick.AddListener(() =>
            {
                isFadeOut = true;
                isStartBtn = true;
                FadePanel.gameObject.SetActive(true);
            });

        if (LogoutBtn != null)
            LogoutBtn.onClick.AddListener(() =>
            {
                GlobalValue.g_Unique_ID = "";
                GlobalValue.g_NickName = "";
                GlobalValue.g_BestScore = 0;
                
                isFadeOut = true;
                FadePanel.gameObject.SetActive(true);
                //SceneManager.LoadScene("Title");
            });

        GetScoreListUrl = "http://beatleg.dothome.co.kr/Zombie_Get_ID_Rank.php";
    }

    bool a_IsFirst = true;
    // Update is called once per frame
    void Update()
    {
        if (isFadeIn)
        {
            TimeTic -= Time.deltaTime;
            FadeColor = FadePanel.color;
            FadeColor.a = TimeTic / FadeTime;
            FadePanel.color = FadeColor;
            if (TimeTic < 0)
            {
                isFadeIn = false;
                TimeTic = 1.0f;
                FadePanel.gameObject.SetActive(false);
            }
        }

        if (isFadeOut)
        {
            TimeTic -= Time.deltaTime;
            FadeColor = FadePanel.color;
            FadeColor.a = (FadeTime - TimeTic) / FadeTime;
            FadePanel.color = FadeColor;

            if (TimeTic < 0)
                if (isStartBtn)
                    SceneManager.LoadScene("InGame");
                else
                    SceneManager.LoadScene("Title");
        }

        if (isShowing)
        {
            if (RankPanel.transform.localPosition.x < 400)
                RankPanel.transform.localPosition = new Vector3(RankPanel.transform.localPosition.x + 15, 
                    RankPanel.transform.localPosition.y, RankPanel.transform.localPosition.z);
        }
        else
        {
            if (RankPanel.transform.localPosition.x > 0)
                RankPanel.transform.localPosition = new Vector3(RankPanel.transform.localPosition.x - 15, 
                    RankPanel.transform.localPosition.y, RankPanel.transform.localPosition.z);
        }

        if (a_IsFirst == true)
        {
            if (GlobalValue.g_Unique_ID != "")
            {
                StartCoroutine(GetScoreListCo());
            }
            a_IsFirst = false;
        }

        m_RestoreTick += Time.deltaTime;
        if (7.0f <= m_RestoreTick)
        {
            //Debug.Log("RestoreTick");
            if (GlobalValue.g_Unique_ID != "")
            {
                StopCoroutine(GetScoreListCo());
                StartCoroutine(GetScoreListCo());
            }
            m_RestoreTick = 0.0f;
        }

        RankShow();
    }

    IEnumerator GetScoreListCo()
    {
        if (GlobalValue.g_Unique_ID == "")
        {
            yield break;            //로그인 실패 상태라면 그냥 리턴
        }

        WWWForm form = new WWWForm();
        form.AddField("Input_user", GlobalValue.g_Unique_ID, System.Text.Encoding.UTF8);
        var webRequest = new WWW(GetScoreListUrl, form);
        yield return webRequest;

        System.Text.Encoding enc = System.Text.Encoding.UTF8; //<--이렇게 해야 안드로이드에서 한글이 않깨진다.
        string a_ReStr = enc.GetString(webRequest.bytes);

        if (string.IsNullOrEmpty(webRequest.error))
        {
            if (a_ReStr.Contains("Get_score_list_Success~") == true)
            {
                //점수를 표시하는 함수를 호출
                RecRankList_MyRank(a_ReStr);
            }
        }
        else
        {
            Debug.Log("Error : " + webRequest.error);
        }

        //yield return null;
    }


    void RecRankList_MyRank(string strJsonData)
    {
        m_RkList.Clear();

        //JSON 파일 파싱
        var N = JSON.Parse(strJsonData);

        int ranking = 0;
        UserInfo a_UserNd;
        for (int i = 0; i < N["RkList"].Count; i++)
        {
            ranking = i + 1;
            string userID = N["RkList"][i]["user_id"];
            string nick_name = N["RkList"][i]["nick_name"];
            int best_score = N["RkList"][i]["best_score"].AsInt;

            a_UserNd = new UserInfo();
            a_UserNd.m_ID = userID;
            a_UserNd.m_Nick = nick_name;
            a_UserNd.m_BestScore = best_score;
            m_RkList.Add(a_UserNd);

        }//for (int i = 0; i < N["RkList"].Count; i++)

        m_My_Rank = N["my_rank"].AsInt;
    }

    void RankShow()
    {
        RankTxt.text = "My Score  :  " + GlobalValue.g_BestScore + "  " + GlobalValue.g_NickName + "\n\n";

        for(int i = 0; i < m_RkList.Count; i++)
        {
            if (m_RkList[i].m_ID == GlobalValue.g_Unique_ID)
            {
                RankTxt.text += "<color=#ff0000><size=25>" + "No." + (i + 1) + "  " + m_RkList[i].m_BestScore + "  " + m_RkList[i].m_Nick + "\n\n" + "</size></color>";
            }
            else
                RankTxt.text += "No." + (i + 1) + "  " + m_RkList[i].m_BestScore + "  " + m_RkList[i].m_Nick + "\n\n";
        }
    }

#if UNITY_EDITOR
    void OnGUI()
    {
        GUI.Label(new Rect(20, 20, 1500, 60),
                          "<color=#ffff00><size=24>" +
                          "내정보 : 별명(" + GlobalValue.g_NickName +
                          ") : 순위(" + m_My_Rank.ToString() + "등) : 점수(" +
                          GlobalValue.g_BestScore.ToString() + "점)" +                         
                          "</size></color>");

        string a_TempStr;
        for (int ii = 0; ii < m_RkList.Count; ii++)
        {
            a_TempStr = (ii + 1).ToString() + "등 : \"" +
                        m_RkList[ii].m_ID + "\"(" + m_RkList[ii].m_Nick + ") : " +
                        m_RkList[ii].m_BestScore.ToString() + " 점";

            if (m_RkList[ii].m_ID == GlobalValue.g_Unique_ID)
            {
                GUI.Label(new Rect(20, (ii * 34) + 71, 1500, 60),
                    "<color=#ff0000><size=25>" + a_TempStr + "</size></color>");
            }
            else
            {
                GUI.Label(new Rect(20, (ii * 34) + 71, 1500, 60),
                    "<color=#ffffff><size=25>" + a_TempStr + "</size></color>");
            }
        }//for (int ii = 0; ii < m_RkList.Count; ii++)

    }//void OnGUI()
#endif
}
