﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameMgr : MonoBehaviour
{
    public Image FadePanel;
    Color FadeColor;
    bool isFadeIn = true;
    bool isFadeOut = false;
    float FadeTime = 1.0f;
    float TimeTic;

    public Transform[] points;
    public GameObject monsterPrefab;
    public List<GameObject> monsterPool = new List<GameObject>();

    public float createTime;
    public int maxMonster;
    public bool isGameOver = false;

    public static GameMgr instance = null;

    private void Awake()
    {
        instance = this;
    }

    // Start is called before the first frame update
    void Start()
    {
        TimeTic = FadeTime;

        points = GameObject.Find("SpawnPoint").GetComponentsInChildren<Transform>();

        for(int i = 0; i < maxMonster; i++)
        {
            GameObject monster = (GameObject)Instantiate(monsterPrefab);
            monster.name = "Monster_" + i.ToString();
            monster.SetActive(false);
            monsterPool.Add(monster);
        }

        if(points.Length > 0)
        {
            StartCoroutine(CreateMonster());
        }
    }

    IEnumerator CreateMonster()
    {
        while (!isGameOver)
        {
            yield return new WaitForSeconds(createTime);

            if (isGameOver) yield break;

            foreach(GameObject monster in monsterPool)
            {
                if (!monster.activeSelf)
                {
                    int idx = Random.Range(1, points.Length);
                    monster.transform.position = points[idx].position;
                    monster.SetActive(true);
                    break;
                }
            }            
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (isFadeIn)
        {
            TimeTic -= Time.deltaTime;
            FadeColor = FadePanel.color;
            FadeColor.a = TimeTic / FadeTime;
            FadePanel.color = FadeColor;
            if (TimeTic < 0)
            {
                isFadeIn = false;
                TimeTic = 1.0f;
                FadePanel.gameObject.SetActive(false);
            }
        }
    }
}
